const translations = {
    "ar": {
        "admin_title": "أبشر PRO ADMIN",
        "admin_subtitle": "بوابة التحكم الشاملة في الخدمات والشقق والحسابات",
        "general_stats": "الإحصائيات العامة",
        "customer_service_chat": "شات خدمة العملاء",
        "bookings_requests": "الحجوزات وطلبات السكن",
        "apartments_manage": "إدارة الشقق (مع السعة)",
        "student_services": "الخدمات الطلابية",
        "universities": "الجامعات",
        "districts": "الأحياء السكنية",
        "reviews": "تقييمات وآراء الطلاب",
        "students_accounts": "بيانات وحسابات الطلاب",
        "georgia_news": "أخبار جورجيا 📰",
        "notifications": "التنبيهات والإشعارات 🔔",
        "server_conn": "الاتصال بالخادم:",
        "online_sim": "متصل (المحاكاة نشطة)",
        "add_apartment": "إضافة شقة جديدة",
        "add_service": "إضافة خدمة جديدة",
        "add_university": "إضافة جامعة جديدة",
        "add_district": "إضافة حي جديد",
        "add_student": "إضافة حساب طالب",
        "add_news": "نشر خبر جديد",
        "add_notification": "نشر تنبيه عاجل جديد 🔔",
        "overview_title": "نظرة عامة على نشاط الموقع والتطبيق",
        "overview_subtitle": "ملخص فوري للبيانات المسجلة والحجوزات النشطة",
        "apartments": "الشقق السكنية",
        "available_students": "متاحة للطلاب حالياً",
        "available_services": "الخدمات المتاحة",
        "logistic_services": "خدمة طلابية ولوجستية",
        "students_clients": "الطلاب والعملاء",
        "registered_account": "حساب مسجل بالمنصة",
        "pending_requests": "طلبات قيد المراجعة",
        "needs_followup": "تحتاج لمتابعة الإدارة",
        "quick_add": "⚡ أضف جديداً إلى التطبيق في ثوانٍ!",
        "quick_add_desc": "أي إضافة تقوم بها هنا تنعكس مباشرة في متصفح الموقع وتطبيق الهاتف المحمول فلاتر.",
        "search_apt": "🔍 ابحث برقم الشقة (مثال: 1 أو #1) أو عنوان الشقة...",
        "apt_title": "إدارة الشقق السكنية",
        "apt_desc": "إضافة، تعديل، أو حذف الشقق المعروضة للطلاب في تبليسي",
        "svc_title": "إدارة الخدمات الطلابية",
        "svc_desc": "التحكم في خدمات الصيانة والإقامة والاستقبال",
        "uni_title": "إدارة الجامعات",
        "uni_desc": "إضافة أو حذف الجامعات التي سيتم استخدامها في فلاتر التطبيق",
        "dist_title": "إدارة الأحياء السكنية",
        "dist_desc": "إضافة أو حذف الأحياء السكنية المتاحة في تبليسي والتي سيتم استخدامها في فلتر السكن",
        "chat_title": "شات خدمة العملاء (نظام محادثات فوري)",
        "chat_desc": "المحادثات مرتبة تحت بعضها بشكل عمودي حسب الأحدث وقتاً للرد المباشر والسريع على استفسارات وحجوزات الطلاب",
        "active_chats": "المحادثات النشطة",
        "live": "مباشر",
        "select_chat": "اختر محادثة من القائمة الجانبية (المرتبة حسب الوقت) لعرض استفسارات وحجوزات الطالب والرد عليها فوراً بأسلوب الواتساب.",
        "whatsapp_direct": "وتساب فوري",
        "block": "حظر",
        "reply_to": "↩️ الرد على رسالة:",
        "type_reply": "اكتب رسالتك و ردك على استفسار وحجز الطالب هنا...",
        "upload_image": "تحميل صورة 📷",
        "attach_link": "إرفاق رابط",
        "attach_video": "إرفاق فيديو (تحت التطوير 🚧)",
        "send_reply": "إرسال الرد",
        "req_title": "إدارة الحجوزات وطلبات السكن وتجميع الشباب",
        "req_desc": "متابعة وتحديث حالات طلبات الطلاب الجامعيين مع تفاصيل الحجز الكاملة وإمكانية الرد عبر الواتساب",
        "search_req": "🔍 ابحث برقم الطلب، اسم الطالب، أو رقم الواتساب...",
        "req_num": "# الطلب",
        "student_name": "اسم الطالب",
        "uni_nationality": "الجامعة والجنسية",
        "whatsapp": "الواتساب",
        "svc_details": "نوع الخدمة والتفاصيل",
        "status": "الحالة",
        "actions": "إجراءات",
        "rev_title": "تقييمات وآراء الطلاب في الخدمات والتطبيق",
        "rev_desc": "عرض آراء وانطباعات الطلاب الجامعيين في تبليسي",
        "std_title": "حسابات الطلاب والعملاء",
        "std_desc": "قائمة الحسابات المسجلة في منصة وتطبيق أبشر مع التفاصيل الكاملة",
        "full_name": "الاسم الكامل",
        "email": "البريد الإلكتروني",
        "phone": "رقم الهاتف",
        "registration_date": "تاريخ التسجيل",
        "wallet_points": "نقاط المحفظة",
        "manage_points": "إدارة النقاط",
        "delete": "حذف",
        "news_title": "إدارة أخبار جورجيا",
        "news_desc": "نشر وإدارة الأخبار والمستجدات والمقالات المفيدة للطلاب في جورجيا",
        "attached_image": "الصورة المرفقة",
        "title": "العنوان",
        "content_details": "المحتوى والتفاصيل",
        "publish_date": "تاريخ النشر",
        "notif_title": "إدارة التنبيهات والإشعارات العاجلة",
        "notif_desc": "نشر التنبيهات العاجلة للطلاب (انقطاع مياه/كهرباء، تفاصيل الصلاة والأنشطة). تختفي تلقائياً بعد مرور 48 ساعة.",
        "notif_heading": "عنوان التنبيه",
        "notif_content": "محتوى التنبيه والتفاصيل",
        "notif_status": "حالة التنبيه",
        "manage": "إدارة",
        "cancel": "إلغاء",
        "save_add": "حفظ وإضافة الطالب",
        "execute_op": "تنفيذ العملية وتحديث الرصيد",
        "points_manage_modal": "إدارة نقاط المحفظة للطالب",
        "current_balance": "الرصيد الحالي:",
        "point": "نقطة",
        "op_type": "نوع العملية:",
        "add_points": "إضافة نقاط ➕",
        "withdraw_points": "سحب نقاط ➖",
        "amount_points": "المبلغ / عدد النقاط:",
        "reason_desc": "السبب أو الوصف (يظهر للطالب في الإشعارات):"
    },
    "en": {
        "admin_title": "Absher PRO ADMIN",
        "admin_subtitle": "Comprehensive control portal for services, apartments, and accounts",
        "general_stats": "General Statistics",
        "customer_service_chat": "Customer Service Chat",
        "bookings_requests": "Bookings & Requests",
        "apartments_manage": "Manage Apartments (w/ Capacity)",
        "student_services": "Student Services",
        "universities": "Universities",
        "districts": "Districts",
        "reviews": "Student Reviews",
        "students_accounts": "Student Accounts",
        "georgia_news": "Georgia News 📰",
        "notifications": "Alerts & Notifications 🔔",
        "server_conn": "Server Connection:",
        "online_sim": "Online (Simulation Active)",
        "add_apartment": "Add New Apartment",
        "add_service": "Add New Service",
        "add_university": "Add New University",
        "add_district": "Add New District",
        "add_student": "Add Student Account",
        "add_news": "Publish New News",
        "add_notification": "Publish Urgent Alert 🔔",
        "overview_title": "Site & App Activity Overview",
        "overview_subtitle": "Instant summary of registered data and active bookings",
        "apartments": "Apartments",
        "available_students": "Currently available for students",
        "available_services": "Available Services",
        "logistic_services": "Student and logistics service",
        "students_clients": "Students & Clients",
        "registered_account": "Account registered on platform",
        "pending_requests": "Pending Requests",
        "needs_followup": "Needs management follow-up",
        "quick_add": "⚡ Add new to app in seconds!",
        "quick_add_desc": "Any addition you make here reflects directly in the website browser and Flutter mobile app.",
        "search_apt": "🔍 Search by apartment number (e.g. 1 or #1) or address...",
        "apt_title": "Manage Apartments",
        "apt_desc": "Add, edit, or delete apartments shown to students in Tbilisi",
        "svc_title": "Manage Student Services",
        "svc_desc": "Control maintenance, accommodation, and reception services",
        "uni_title": "Manage Universities",
        "uni_desc": "Add or delete universities used in app filters",
        "dist_title": "Manage Districts",
        "dist_desc": "Add or delete districts available in Tbilisi used in housing filters",
        "chat_title": "Customer Service Chat (Instant Messaging)",
        "chat_desc": "Chats are arranged vertically by latest time for direct and quick response to student inquiries and bookings",
        "active_chats": "Active Chats",
        "live": "Live",
        "select_chat": "Select a chat from the sidebar (sorted by time) to view student inquiries and reply instantly like WhatsApp.",
        "whatsapp_direct": "Direct WhatsApp",
        "block": "Block",
        "reply_to": "↩️ Reply to:",
        "type_reply": "Type your message and reply to student here...",
        "upload_image": "Upload Image 📷",
        "attach_link": "Attach Link",
        "attach_video": "Attach Video (WIP 🚧)",
        "send_reply": "Send Reply",
        "req_title": "Manage Bookings, Housing & Roommates",
        "req_desc": "Track and update university student request statuses with full booking details and WhatsApp reply option",
        "search_req": "🔍 Search by request #, student name, or WhatsApp...",
        "req_num": "Request #",
        "student_name": "Student Name",
        "uni_nationality": "University & Nationality",
        "whatsapp": "WhatsApp",
        "svc_details": "Service Type & Details",
        "status": "Status",
        "actions": "Actions",
        "rev_title": "Student Reviews & Opinions",
        "rev_desc": "View opinions and impressions of university students in Tbilisi",
        "std_title": "Student & Client Accounts",
        "std_desc": "List of accounts registered in Absher platform with full details",
        "full_name": "Full Name",
        "email": "Email Address",
        "phone": "Phone Number",
        "registration_date": "Registration Date",
        "wallet_points": "Wallet Points",
        "manage_points": "Manage Points",
        "delete": "Delete",
        "news_title": "Manage Georgia News",
        "news_desc": "Publish and manage news, updates, and useful articles for students in Georgia",
        "attached_image": "Attached Image",
        "title": "Title",
        "content_details": "Content & Details",
        "publish_date": "Publish Date",
        "notif_title": "Manage Urgent Alerts & Notifications",
        "notif_desc": "Publish urgent alerts to students (water/electricity cuts, prayer details). Disappears automatically after 48 hours.",
        "notif_heading": "Alert Title",
        "notif_content": "Alert Content & Details",
        "notif_status": "Alert Status",
        "manage": "Manage",
        "cancel": "Cancel",
        "save_add": "Save & Add Student",
        "execute_op": "Execute Operation & Update Balance",
        "points_manage_modal": "Manage Student Wallet Points",
        "current_balance": "Current Balance:",
        "point": "Point",
        "op_type": "Operation Type:",
        "add_points": "Add Points ➕",
        "withdraw_points": "Withdraw Points ➖",
        "amount_points": "Amount / Number of Points:",
        "reason_desc": "Reason or Description (shows to student):"
    }
};

let currentLang = localStorage.getItem('admin_lang') || 'ar';

function toggleLanguage() {
    currentLang = currentLang === 'ar' ? 'en' : 'ar';
    localStorage.setItem('admin_lang', currentLang);
    applyLanguage();
}

function tr(arText) {
    if (currentLang === 'ar') return arText;
    
    // Find key by searching the 'ar' dictionary for the exact text
    const entries = Object.entries(translations['ar']);
    for (let [key, val] of entries) {
        if (val.trim() === arText.trim()) {
            return translations['en'][key] || arText;
        }
    }
    return arText; // Fallback
}

function applyLanguage() {
    document.documentElement.lang = currentLang;
    document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr';
    
    // Dynamically walk text nodes in the body and translate them!
    walkAndTranslate(document.body);
    
    // Also re-render dynamic tables so they get translated
    if (typeof renderApartments === 'function') {
        renderStats();
        renderApartments();
        renderServices();
        renderRequests();
        renderStudents();
        renderUniversities();
        renderDistricts();
        renderReviews();
        renderNews();
        renderNotifications();
    }
}

// Store original Arabic text on elements to allow flipping back
function walkAndTranslate(node) {
    if (node.nodeType === 3) { // Text node
        const text = node.nodeValue.trim();
        if (text) {
            if (!node.parentElement.hasAttribute('data-orig-text')) {
                node.parentElement.setAttribute('data-orig-text', text);
            }
            const orig = node.parentElement.getAttribute('data-orig-text');
            const translated = tr(orig);
            if (translated !== orig) {
                node.nodeValue = node.nodeValue.replace(text, translated);
            } else if (currentLang === 'ar') {
                node.nodeValue = node.nodeValue.replace(text, orig);
            }
        }
    } else if (node.nodeType === 1 && node.nodeName !== "SCRIPT" && node.nodeName !== "STYLE") {
        for (let i = 0; i < node.childNodes.length; i++) {
            walkAndTranslate(node.childNodes[i]);
        }
    }
}

// Ensure language applies on load
document.addEventListener("DOMContentLoaded", () => {
    if (currentLang === 'en') {
        applyLanguage();
    }
});
