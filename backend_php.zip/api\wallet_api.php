<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json; charset=UTF-8");

$input = json_decode(file_get_contents("php://input"), true) ?? $_POST;
$action = $_GET['action'] ?? ($input['action'] ?? '');
$studentId = $input['student_id'] ?? null;

$jsonFile = __DIR__ . '/../admin/database.json';
if (!file_exists($jsonFile)) {
    echo json_encode(["status" => "error", "message" => "قاعدة البيانات غير متوفرة"], JSON_UNESCAPED_UNICODE);
    exit();
}
$dbData = json_decode(file_get_contents($jsonFile), true);

if ($action === 'get_wallet') {
    if (!$studentId) {
        echo json_encode(["status" => "error", "message" => "معرف الطالب مطلوب"], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // Find student points
    $points = 0;
    if (isset($dbData['students'])) {
        foreach ($dbData['students'] as $student) {
            if ($student['id'] == $studentId) {
                $points = $student['points'] ?? 0;
                break;
            }
        }
    }
    
    // Filter notifications for student
    $notifications = [];
    if (isset($dbData['notifications'])) {
        foreach ($dbData['notifications'] as $notif) {
            if (isset($notif['student_id']) && $notif['student_id'] == $studentId) {
                $notifications[] = $notif;
            }
        }
        $notifications = array_reverse($notifications);
    }
    
    echo json_encode([
        "status" => "success",
        "points" => $points,
        "notifications" => $notifications
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($action === 'pay_with_points') {
    $amount = (int)($input['amount'] ?? 0);
    $serviceTitle = $input['service_title'] ?? 'خدمة';
    
    if (!$studentId || $amount <= 0) {
        echo json_encode(["status" => "error", "message" => "البيانات غير مكتملة"], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    $studentIndex = -1;
    $currentPoints = 0;
    if (isset($dbData['students'])) {
        foreach ($dbData['students'] as $idx => $student) {
            if ($student['id'] == $studentId) {
                $studentIndex = $idx;
                $currentPoints = $student['points'] ?? 0;
                break;
            }
        }
    }
    
    if ($studentIndex === -1) {
        echo json_encode(["status" => "error", "message" => "الطالب غير موجود"], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if ($currentPoints < $amount) {
        echo json_encode(["status" => "error", "message" => "رصيد النقاط غير كافٍ لإتمام العملية"], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // Deduct points
    $dbData['students'][$studentIndex]['points'] = $currentPoints - $amount;
    
    // Add notification
    if (!isset($dbData['notifications'])) {
        $dbData['notifications'] = [];
    }
    $dbData['notifications'][] = [
        "id" => time(),
        "student_id" => $studentId,
        "title" => "تم خصم نقاط من محفظتك 📉",
        "content" => "تم خصم $amount نقطة مقابل خدمة: $serviceTitle",
        "created_at" => date('Y-m-d h:i A')
    ];
    
    file_put_contents($jsonFile, json_encode($dbData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    echo json_encode([
        "status" => "success",
        "message" => "تم الخصم بنجاح",
        "new_balance" => $currentPoints - $amount
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

echo json_encode(["status" => "error", "message" => "إجراء غير صالح"], JSON_UNESCAPED_UNICODE);
?>
